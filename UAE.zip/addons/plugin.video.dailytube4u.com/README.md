DailyTube4U.com
===============

#### About the service ####
Watch a huge variety of OnDemand online Arabic TV streams provided and maintained by dailytube4u.com.

The service includes TV shows such as Al Qahera Al Youm, Al Bernameg, Akher Kalam, Nas Book, Ibrahim Wal Nas and others.

Using the XBMC plugin
---------------------
#### Installation ####
Install the **[Arabic XBMC addons repository](https://github.com/hadynz/repository.arabic.xbmc-addons#arabic-xbmc-repository)** and select to install this plugin from it.

#### Configuration #####
No configuration is required for this plugin.